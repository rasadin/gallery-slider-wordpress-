/* Initialize jQuery Colorbox*/
jQuery(function( $ ){
    $('a[href*=".jpg"], a[href*=".jpeg"], a[href*=".png"], a[href*=".gif"]').colorbox({
       transition:'none',
       rel: 'gallery',
       opacity:.85,
       maxWidth:"80%",
       maxHeight:"80%",
       slideshow:"true",
       slideshowSpeed: 14000,
    
       title: function() {
        // console.log($(this).siblings('.blocks-gallery-item__caption').html());
        //    return $(this).find('img').attr('alt'); // this return alt with image
        return $(this).siblings('.blocks-gallery-item__caption').html(); //this retur caption with image

       } 
       });
   });